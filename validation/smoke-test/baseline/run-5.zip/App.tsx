import React, { useState } from 'react';
import { AuthState, User, Organization } from './types';
import { Login } from './pages/Login';
import { Dashboard } from './pages/Dashboard';
import { MainLayout } from './components/Layout/MainLayout';
import * as api from './services/mockService';

const App: React.FC = () => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    organization: null,
    isAuthenticated: false,
  });
  const [availableOrgs, setAvailableOrgs] = useState<Organization[]>([]);
  const [isLoginLoading, setIsLoginLoading] = useState(false);

  const handleLogin = async (email: string) => {
    setIsLoginLoading(true);
    try {
      const { user, orgs } = await api.mockLogin(email);
      setAvailableOrgs(orgs);
      setAuthState({
        user,
        organization: orgs[0],
        isAuthenticated: true,
      });
    } catch (error) {
      console.error('Login failed', error);
      alert('Login failed. Please try again.');
    } finally {
      setIsLoginLoading(false);
    }
  };

  const handleLogout = () => {
    setAuthState({
      user: null,
      organization: null,
      isAuthenticated: false,
    });
  };

  const handleSwitchOrg = (orgId: string) => {
    const org = availableOrgs.find(o => o.id === orgId);
    if (org) {
      setAuthState(prev => ({ ...prev, organization: org }));
    }
  };

  if (!authState.isAuthenticated) {
    return <Login onLogin={handleLogin} isLoading={isLoginLoading} />;
  }

  // Safe to assume these exist if authenticated based on logic above
  const user = authState.user as User;
  const currentOrg = authState.organization as Organization;

  return (
    <MainLayout
      user={user}
      currentOrg={currentOrg}
      organizations={availableOrgs}
      onSwitchOrg={handleSwitchOrg}
      onLogout={handleLogout}
    >
      <Dashboard currentOrg={currentOrg} />
    </MainLayout>
  );
};

export default App;