import { FileRecord, JobStatus, Organization, User } from '../types';

// Mock Data
const MOCK_USER: User = {
  id: 'u_1',
  name: 'Alex Developer',
  email: 'alex@example.com',
  avatarUrl: 'https://picsum.photos/200',
};

const MOCK_ORGS: Organization[] = [
  { id: 'o_1', name: 'Acme Corp', slug: 'acme' },
  { id: 'o_2', name: 'Globex Inc', slug: 'globex' },
];

let filesStore: FileRecord[] = [
  {
    id: 'f_1',
    name: 'q1_report.pdf',
    size: 1024 * 1024 * 2.5,
    type: 'application/pdf',
    uploadedAt: new Date(Date.now() - 10000000).toISOString(),
    status: JobStatus.COMPLETED,
    organizationId: 'o_1',
    progress: 100,
  },
  {
    id: 'f_2',
    name: 'dataset_v2.csv',
    size: 1024 * 1024 * 150,
    type: 'text/csv',
    uploadedAt: new Date(Date.now() - 500000).toISOString(),
    status: JobStatus.FAILED,
    organizationId: 'o_1',
    progress: 45,
  }
];

export const mockLogin = async (email: string): Promise<{ user: User; orgs: Organization[] }> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ user: { ...MOCK_USER, email }, orgs: MOCK_ORGS });
    }, 800);
  });
};

export const getFiles = async (orgId: string): Promise<FileRecord[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(filesStore.filter(f => f.organizationId === orgId));
    }, 500);
  });
};

export const uploadFileMock = async (file: File, orgId: string): Promise<FileRecord> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const newFile: FileRecord = {
        id: `f_${Date.now()}`,
        name: file.name,
        size: file.size,
        type: file.type,
        uploadedAt: new Date().toISOString(),
        status: JobStatus.QUEUED,
        organizationId: orgId,
        progress: 0,
      };
      filesStore = [newFile, ...filesStore];
      resolve(newFile);
      
      // Simulate Celery Background Job
      simulateProcessing(newFile.id);
    }, 1000);
  });
};

// Simulates a Celery worker picking up the task
const simulateProcessing = (fileId: string) => {
  // 1. Move to Processing after random delay
  setTimeout(() => {
    updateFileStatus(fileId, JobStatus.PROCESSING, 10);
    
    // 2. Simulate progress updates
    let progress = 10;
    const interval = setInterval(() => {
      progress += Math.floor(Math.random() * 20);
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        updateFileStatus(fileId, JobStatus.COMPLETED, 100);
      } else {
        updateFileStatus(fileId, JobStatus.PROCESSING, progress);
      }
    }, 1500);
    
  }, 2000);
};

const updateFileStatus = (id: string, status: JobStatus, progress: number) => {
  filesStore = filesStore.map(f => f.id === id ? { ...f, status, progress } : f);
};

// Helper for polling updates in the UI
export const getFileStatus = async (id: string): Promise<FileRecord | undefined> => {
    return filesStore.find(f => f.id === id);
};