export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
}

export interface Organization {
  id: string;
  name: string;
  slug: string;
}

export enum JobStatus {
  QUEUED = 'QUEUED',
  PROCESSING = 'PROCESSING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
}

export interface FileRecord {
  id: string;
  name: string;
  size: number;
  type: string;
  uploadedAt: string;
  status: JobStatus;
  organizationId: string;
  processedUrl?: string;
  progress: number; // 0-100
}

export interface AuthState {
  user: User | null;
  organization: Organization | null;
  isAuthenticated: boolean;
}