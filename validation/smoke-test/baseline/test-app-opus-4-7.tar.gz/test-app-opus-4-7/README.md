# Multi-Tenant File Upload API

Flask + Flask-Login + SQLAlchemy + Celery + Redis.

## Layout

```
app/
  __init__.py     # app factory, blueprint registration
  extensions.py   # db, login_manager, celery
  models.py       # Organization, User, File
  auth.py         # /auth register, login, logout, me
  files.py        # /files upload, list, view, download
  tasks.py        # Celery task: process_file
config.py
run.py            # Flask entrypoint (also: `flask --app run.py init-db`)
celery_worker.py  # Celery entrypoint
```

## Multi-tenancy

- Every `User` belongs to exactly one `Organization` (`organization_id` FK).
- `User.email` is unique *within* an organization, not globally.
- Every `File` carries `organization_id`; all reads filter by `current_user.organization_id`, so users can only see their org's files.
- Uploads are stored on disk under `uploads/<org_id>/<uuid>_<filename>`.

## Run it

```bash
pip install -r requirements.txt

# 1. Start Redis (broker + result backend)
redis-server

# 2. Start the Flask app (also creates tables on first run)
python run.py

# 3. Start a Celery worker in another shell
celery -A celery_worker.celery_app worker --loglevel=info
```

## Endpoints

| Method | Path                         | Description                          |
|--------|------------------------------|--------------------------------------|
| POST   | `/auth/register`             | Create org (if new) + user, log in   |
| POST   | `/auth/login`                | Log in (org slug + email + password) |
| POST   | `/auth/logout`               | Log out                              |
| GET    | `/auth/me`                   | Current user + org                   |
| POST   | `/files`                     | Multipart upload, returns task id    |
| GET    | `/files`                     | List files in caller's org           |
| GET    | `/files/<id>`                | File metadata + processing result    |
| GET    | `/files/<id>/download`       | Download original bytes              |
| GET    | `/health`                    | Liveness                             |

## Example

```bash
# Register
curl -c jar -H 'Content-Type: application/json' \
  -d '{"email":"a@acme.com","password":"hunter2","organization":"Acme"}' \
  http://localhost:5000/auth/register

# Upload
curl -b jar -F file=@./sample.csv http://localhost:5000/files

# Poll
curl -b jar http://localhost:5000/files/1
```

The background task hashes the file and counts lines as a placeholder for
real work (parsing, OCR, virus scanning, etc.). Replace the body of
`process_file` in `app/tasks.py` to do something useful.
