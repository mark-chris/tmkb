import re

from flask import Blueprint, jsonify, request
from flask_login import current_user, login_required, login_user, logout_user

from .extensions import db
from .models import Organization, User

bp = Blueprint("auth", __name__)

SLUG_RE = re.compile(r"[^a-z0-9]+")


def slugify(value):
    return SLUG_RE.sub("-", value.lower()).strip("-")


@bp.post("/register")
def register():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    org_name = (data.get("organization") or "").strip()

    if not email or not password or not org_name:
        return jsonify(error="email, password, and organization are required"), 400

    slug = slugify(org_name)
    org = Organization.query.filter_by(slug=slug).first()
    if org is None:
        org = Organization(name=org_name, slug=slug)
        db.session.add(org)
        db.session.flush()

    if User.query.filter_by(organization_id=org.id, email=email).first():
        return jsonify(error="user already exists in this organization"), 409

    user = User(organization_id=org.id, email=email)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

    login_user(user)
    return (
        jsonify(
            user={"id": user.id, "email": user.email},
            organization={"id": org.id, "name": org.name, "slug": org.slug},
        ),
        201,
    )


@bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    org_slug = (data.get("organization") or "").strip().lower()

    if not email or not password or not org_slug:
        return jsonify(error="email, password, and organization are required"), 400

    org = Organization.query.filter_by(slug=org_slug).first()
    if org is None:
        return jsonify(error="invalid credentials"), 401

    user = User.query.filter_by(organization_id=org.id, email=email).first()
    if user is None or not user.check_password(password):
        return jsonify(error="invalid credentials"), 401

    login_user(user)
    return jsonify(
        user={"id": user.id, "email": user.email},
        organization={"id": org.id, "name": org.name, "slug": org.slug},
    )


@bp.post("/logout")
@login_required
def logout():
    logout_user()
    return jsonify(status="logged out")


@bp.get("/me")
@login_required
def me():
    return jsonify(
        user={"id": current_user.id, "email": current_user.email},
        organization={
            "id": current_user.organization.id,
            "name": current_user.organization.name,
            "slug": current_user.organization.slug,
        },
    )
