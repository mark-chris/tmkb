import uuid
from pathlib import Path

from flask import Blueprint, current_app, jsonify, request, send_file
from flask_login import current_user, login_required
from werkzeug.utils import secure_filename

from .extensions import db
from .models import File
from .tasks import process_file

bp = Blueprint("files", __name__)


def _allowed(filename):
    if "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in current_app.config["ALLOWED_EXTENSIONS"]


def _org_upload_dir():
    base = Path(current_app.config["UPLOAD_FOLDER"]) / str(current_user.organization_id)
    base.mkdir(parents=True, exist_ok=True)
    return base


@bp.post("")
@login_required
def upload():
    if "file" not in request.files:
        return jsonify(error="no file part"), 400

    upload = request.files["file"]
    if not upload.filename:
        return jsonify(error="empty filename"), 400

    safe_name = secure_filename(upload.filename)
    if not safe_name or not _allowed(safe_name):
        return jsonify(error="file type not allowed"), 400

    stored_name = f"{uuid.uuid4().hex}_{safe_name}"
    target = _org_upload_dir() / stored_name
    upload.save(target)

    record = File(
        organization_id=current_user.organization_id,
        uploader_id=current_user.id,
        original_filename=safe_name,
        stored_filename=stored_name,
        content_type=upload.mimetype,
        size_bytes=target.stat().st_size,
        status=File.STATUS_PENDING,
    )
    db.session.add(record)
    db.session.commit()

    async_result = process_file.delay(record.id)

    return (
        jsonify(file=record.to_dict(), task_id=async_result.id),
        202,
    )


@bp.get("")
@login_required
def list_files():
    status = request.args.get("status")
    query = File.query.filter_by(organization_id=current_user.organization_id)
    if status:
        query = query.filter_by(status=status)
    files = query.order_by(File.created_at.desc()).all()
    return jsonify(files=[f.to_dict() for f in files])


@bp.get("/<int:file_id>")
@login_required
def get_file(file_id):
    record = File.query.filter_by(
        id=file_id, organization_id=current_user.organization_id
    ).first()
    if record is None:
        return jsonify(error="not found"), 404
    return jsonify(file=record.to_dict(include_result=True))


@bp.get("/<int:file_id>/download")
@login_required
def download_file(file_id):
    record = File.query.filter_by(
        id=file_id, organization_id=current_user.organization_id
    ).first()
    if record is None:
        return jsonify(error="not found"), 404

    path = (
        Path(current_app.config["UPLOAD_FOLDER"])
        / str(record.organization_id)
        / record.stored_filename
    )
    if not path.exists():
        return jsonify(error="file missing on disk"), 410

    return send_file(
        path,
        as_attachment=True,
        download_name=record.original_filename,
        mimetype=record.content_type or "application/octet-stream",
    )
