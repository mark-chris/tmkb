from flask import Flask, jsonify

from config import Config

from .extensions import db, login_manager, migrate, celery_init_app


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    app.config["UPLOAD_FOLDER"].mkdir(parents=True, exist_ok=True)

    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    celery_init_app(app)

    from . import models  # noqa: F401  (register models with SQLAlchemy)

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(models.User, int(user_id))

    @login_manager.unauthorized_handler
    def unauthorized():
        return jsonify(error="authentication required"), 401

    from .auth import bp as auth_bp
    from .files import bp as files_bp

    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(files_bp, url_prefix="/files")

    @app.get("/health")
    def health():
        return {"status": "ok"}

    return app
