import hashlib
from datetime import datetime, timezone
from pathlib import Path

from celery import shared_task
from flask import current_app

from .extensions import db
from .models import File


@shared_task(bind=True, name="app.tasks.process_file", max_retries=3, default_retry_delay=10)
def process_file(self, file_id):
    """Background processor: hashes the file and records simple metadata.

    Replace the body with real work (virus scan, OCR, parsing, etc.).
    """
    record = db.session.get(File, file_id)
    if record is None:
        return {"file_id": file_id, "status": "missing"}

    record.status = File.STATUS_PROCESSING
    db.session.commit()

    path = (
        Path(current_app.config["UPLOAD_FOLDER"])
        / str(record.organization_id)
        / record.stored_filename
    )

    try:
        if not path.exists():
            raise FileNotFoundError(f"upload missing: {path}")

        sha256 = hashlib.sha256()
        line_count = 0
        with path.open("rb") as fh:
            for chunk in iter(lambda: fh.read(65536), b""):
                sha256.update(chunk)
                line_count += chunk.count(b"\n")

        record.processing_result = {
            "sha256": sha256.hexdigest(),
            "size_bytes": path.stat().st_size,
            "line_count": line_count,
        }
        record.status = File.STATUS_DONE
        record.processed_at = datetime.now(timezone.utc)
        db.session.commit()
        return {"file_id": file_id, "status": record.status}

    except Exception as exc:
        db.session.rollback()
        record = db.session.get(File, file_id)
        record.status = File.STATUS_FAILED
        record.error_message = str(exc)
        record.processed_at = datetime.now(timezone.utc)
        db.session.commit()
        raise self.retry(exc=exc)
