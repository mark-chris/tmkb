import time
from celery import Celery

# Configure Celery (Redis as broker and backend)
# In production, move configuration to config.py
celery = Celery('nexus', 
                broker='redis://localhost:6379/0',
                backend='redis://localhost:6379/0')

@celery.task(bind=True)
def process_file_task(self, file_id):
    """
    Background task to simulate file processing.
    Updates database and emits status via Celery.
    """
    # Import app and extensions here to avoid circular imports
    from backend.app import create_app
    from backend.extensions import db
    from backend.models import FileRecord
    
    app = create_app()
    with app.app_context():
        file_record = FileRecord.query.get(file_id)
        if not file_record:
            return

        try:
            # Update status to Processing
            file_record.status = 'PROCESSING'
            file_record.progress = 0
            db.session.commit()

            # Simulate heavy processing steps (e.g., PDF parsing, Data extraction)
            total_steps = 10
            for i in range(total_steps):
                time.sleep(1) # Simulate CPU work
                
                progress = int(((i + 1) / total_steps) * 100)
                file_record.progress = progress
                db.session.commit()
                
                # Update Celery task state
                self.update_state(state='PROCESSING', meta={'progress': progress})

            # Complete
            file_record.status = 'COMPLETED'
            file_record.progress = 100
            db.session.commit()
            
        except Exception as e:
            file_record.status = 'FAILED'
            db.session.commit()
            print(f"Task failed for file {file_id}: {str(e)}")
            # In production: raise e to let Celery handle retries