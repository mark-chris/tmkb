import os
from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename
from backend.extensions import db, login_manager
from backend.models import User, Organization, FileRecord
from backend.tasks import process_file_task

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = 'dev-secret-key' # Change in production
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///nexus.db'
    app.config['UPLOAD_FOLDER'] = os.path.join(os.getcwd(), 'uploads')
    
    # Initialize Extensions
    db.init_app(app)
    login_manager.init_app(app)
    CORS(app, supports_credentials=True) # Enable CORS for frontend communication
    
    # Ensure upload directory exists
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    
    return app

app = create_app()

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- API Endpoints ---

@app.route('/api/init', methods=['POST'])
def init_db():
    """Helper endpoint to initialize database with demo data"""
    with app.app_context():
        db.create_all()
        if not Organization.query.first():
            # Create Demo Tenant
            org = Organization(name="Acme Corp", slug="acme")
            db.session.add(org)
            db.session.commit()
            
            # Create Demo User
            user = User(email="admin@demo.com", name="Admin User", password="password", organization=org)
            db.session.add(user)
            db.session.commit()
            return jsonify({"message": "Database initialized with demo data"})
    return jsonify({"message": "Database already initialized"})

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    
    user = User.query.filter_by(email=email).first()
    
    # In production: Verify password hash here
    if user:
        from flask_login import login_user
        login_user(user)
        return jsonify({
            "user": {"id": str(user.id), "name": user.name, "email": user.email, "avatarUrl": "https://via.placeholder.com/150"},
            "orgs": [{"id": str(user.organization.id), "name": user.organization.name, "slug": user.organization.slug}]
        })
        
    return jsonify({"error": "Invalid credentials"}), 401

@app.route('/api/files', methods=['GET'])
def list_files():
    # In production: Use @login_required and current_user
    org_id = request.args.get('orgId')
    
    if not org_id:
        return jsonify({"error": "Organization ID required"}), 400

    files = FileRecord.query.filter_by(organization_id=org_id).order_by(FileRecord.uploaded_at.desc()).all()
    return jsonify([f.to_dict() for f in files])

@app.route('/api/files/<file_id>', methods=['GET'])
def get_file(file_id):
    file_record = FileRecord.query.get(file_id)
    if not file_record:
        return jsonify({"error": "File not found"}), 404
    return jsonify(file_record.to_dict())

@app.route('/api/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    
    file = request.files['file']
    org_id = request.form.get('orgId')
    
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
        
    if file and org_id:
        filename = secure_filename(file.filename)
        path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        file.save(path)
        
        # Create DB Record
        new_file = FileRecord(
            filename=filename,
            file_path=path,
            size=os.path.getsize(path),
            organization_id=org_id,
            status='QUEUED'
        )
        db.session.add(new_file)
        db.session.commit()
        
        # Trigger Celery Background Job
        process_file_task.delay(new_file.id)
        
        return jsonify(new_file.to_dict()), 201

    return jsonify({"error": "Upload failed"}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
