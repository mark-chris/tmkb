from datetime import datetime
from flask_login import UserMixin
from backend.extensions import db

class Organization(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    slug = db.Column(db.String(50), unique=True, nullable=False)
    users = db.relationship('User', backref='organization', lazy=True)
    files = db.relationship('FileRecord', backref='organization', lazy=True)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    name = db.Column(db.String(100))
    password = db.Column(db.String(128)) # In production, this should be a hash
    organization_id = db.Column(db.Integer, db.ForeignKey('organization.id'), nullable=False)

class FileRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(512))
    size = db.Column(db.Integer)
    status = db.Column(db.String(20), default='QUEUED') # QUEUED, PROCESSING, COMPLETED, FAILED
    progress = db.Column(db.Integer, default=0)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    organization_id = db.Column(db.Integer, db.ForeignKey('organization.id'), nullable=False)

    def to_dict(self):
        return {
            "id": str(self.id),
            "name": self.filename,
            "size": self.size,
            "type": "application/octet-stream",
            "uploadedAt": self.uploaded_at.isoformat(),
            "status": self.status,
            "progress": self.progress,
            "organizationId": str(self.organization_id)
        }