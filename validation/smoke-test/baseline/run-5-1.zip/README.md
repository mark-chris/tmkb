# Nexus SaaS Dashboard (Full Stack)

This project contains a React Frontend and a Flask Backend with Celery background jobs.

## Frontend (React)

The frontend is located in the root directory.
It is currently configured to use `mockService.ts` for preview purposes. 
To connect it to the real backend, you would update the service layer to make `fetch` calls to `http://localhost:5000/api/...`.

## Backend (Flask + Celery)

The backend code is located in the `backend/` directory.

### Prerequisites
- Python 3.9+
- Redis (for Celery)

### Setup

1. **Install Dependencies**
   ```bash
   pip install -r backend/requirements.txt
   ```

2. **Run Redis**
   Make sure Redis is running on port 6379.

3. **Initialize Database**
   Run the app once to create the SQLite DB and mock user:
   ```bash
   curl -X POST http://localhost:5000/api/init
   ```

4. **Run Flask API**
   ```bash
   export PYTHONPATH=$PYTHONPATH:.
   python backend/app.py
   ```
   The API will start on `http://localhost:5000`.

5. **Run Celery Worker**
   Open a new terminal:
   ```bash
   export PYTHONPATH=$PYTHONPATH:.
   celery -A backend.tasks.celery worker --loglevel=info
   ```

### API Endpoints

- `POST /api/login`: Authenticate user.
- `GET /api/files?orgId=1`: List files for an organization.
- `POST /api/upload`: Upload a file and trigger background processing.
- `GET /api/files/<id>`: Get individual file status.
