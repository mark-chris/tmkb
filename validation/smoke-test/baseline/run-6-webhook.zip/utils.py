import hmac
import hashlib
import json
from datetime import datetime


def verify_webhook_signature(payload, signature, secret, algorithm='sha256'):
    """
    Verify webhook signature using HMAC

    Args:
        payload: Raw payload string
        signature: Signature to verify
        secret: Secret key for verification
        algorithm: Hash algorithm to use (default: sha256)

    Returns:
        bool: True if signature is valid, False otherwise
    """
    if algorithm == 'sha256':
        expected_signature = hmac.new(
            secret.encode(),
            payload.encode(),
            hashlib.sha256
        ).hexdigest()
    elif algorithm == 'sha1':
        expected_signature = hmac.new(
            secret.encode(),
            payload.encode(),
            hashlib.sha1
        ).hexdigest()
    else:
        raise ValueError(f"Unsupported algorithm: {algorithm}")

    return hmac.compare_digest(signature, expected_signature)


def parse_github_signature(signature_header):
    """
    Parse GitHub signature header

    Args:
        signature_header: X-Hub-Signature-256 header value

    Returns:
        tuple: (algorithm, signature)
    """
    if not signature_header:
        return None, None

    parts = signature_header.split('=')
    if len(parts) != 2:
        return None, None

    return parts[0], parts[1]


def validate_json_payload(data, required_fields):
    """
    Validate that JSON payload contains required fields

    Args:
        data: JSON data dictionary
        required_fields: List of required field names

    Returns:
        tuple: (is_valid, missing_fields)
    """
    if not data:
        return False, required_fields

    missing = [field for field in required_fields if field not in data]
    return len(missing) == 0, missing


def serialize_datetime(obj):
    """
    JSON serializer for datetime objects

    Args:
        obj: Object to serialize

    Returns:
        str: ISO format datetime string
    """
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Type {type(obj)} not serializable")


def safe_json_loads(data):
    """
    Safely load JSON data with error handling

    Args:
        data: JSON string or bytes

    Returns:
        dict or None: Parsed JSON data or None on error
    """
    try:
        if isinstance(data, bytes):
            data = data.decode('utf-8')
        return json.loads(data)
    except (json.JSONDecodeError, UnicodeDecodeError, AttributeError):
        return None


def create_error_response(message, status_code=400, details=None):
    """
    Create standardized error response

    Args:
        message: Error message
        status_code: HTTP status code
        details: Optional additional details

    Returns:
        dict: Error response dictionary
    """
    response = {
        'error': message,
        'status_code': status_code,
        'timestamp': datetime.utcnow().isoformat()
    }

    if details:
        response['details'] = details

    return response


def create_success_response(data, message=None):
    """
    Create standardized success response

    Args:
        data: Response data
        message: Optional success message

    Returns:
        dict: Success response dictionary
    """
    response = {
        'success': True,
        'data': data,
        'timestamp': datetime.utcnow().isoformat()
    }

    if message:
        response['message'] = message

    return response


def sanitize_webhook_data(data):
    """
    Sanitize webhook data by removing sensitive information

    Args:
        data: Webhook data dictionary

    Returns:
        dict: Sanitized data
    """
    sensitive_keys = [
        'password', 'secret', 'token', 'api_key', 'private_key',
        'access_token', 'refresh_token', 'authorization'
    ]

    if not isinstance(data, dict):
        return data

    sanitized = {}
    for key, value in data.items():
        if any(sensitive in key.lower() for sensitive in sensitive_keys):
            sanitized[key] = '[REDACTED]'
        elif isinstance(value, dict):
            sanitized[key] = sanitize_webhook_data(value)
        elif isinstance(value, list):
            sanitized[key] = [
                sanitize_webhook_data(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            sanitized[key] = value

    return sanitized
