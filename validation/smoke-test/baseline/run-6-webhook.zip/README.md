# Flask Webhook API

A Flask-based API for receiving and processing webhooks from external services asynchronously using Celery.

## Features

- Multiple webhook endpoints (GitHub, Stripe, Slack, Generic)
- Asynchronous processing with Celery
- Webhook signature verification
- Task status tracking
- Health check endpoint
- Error handling and logging

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Start Redis (required for Celery):
```bash
redis-server
```

3. Configure environment variables:
```bash
cp .env.example .env
# Edit .env with your actual secrets
```

4. Start the Flask application:
```bash
python app.py
```

5. Start the Celery worker (in a separate terminal):
```bash
celery -A celery_worker.celery worker --loglevel=info
```

## API Endpoints

### Health Check
- **GET** `/health` - Check if the API is running

### Webhook Endpoints
- **POST** `/webhooks/github` - Receive GitHub webhooks
  - Requires `X-Hub-Signature-256` header

- **POST** `/webhooks/stripe` - Receive Stripe webhooks
  - Requires `Stripe-Signature` header

- **POST** `/webhooks/slack` - Receive Slack webhooks
  - Handles URL verification challenge
  - Requires valid token in payload

- **POST** `/webhooks/generic` - Receive generic webhooks
  - Requires `X-API-Key` header

### Task Status
- **GET** `/tasks/<task_id>` - Get the status of a queued task

## Example Usage

### Send a generic webhook:
```bash
curl -X POST http://localhost:5000/webhooks/generic \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key-here" \
  -d '{"event": "test", "data": {"message": "Hello World"}}'
```

### Check task status:
```bash
curl http://localhost:5000/tasks/<task_id>
```

## Production Deployment

For production, use a production-grade WSGI server like Gunicorn:

```bash
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

And run Celery with proper configuration:

```bash
celery -A celery_worker.celery worker --loglevel=info --concurrency=4
```

## Security Considerations

- Always use HTTPS in production
- Rotate webhook secrets regularly
- Validate all webhook signatures
- Use environment variables for sensitive data
- Implement rate limiting
- Add authentication/authorization as needed
