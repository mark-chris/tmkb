from flask import Flask, request, jsonify
from celery import Celery
import logging
from datetime import datetime
import hmac
import hashlib
import json

app = Flask(__name__)

# Configuration
app.config['CELERY_BROKER_URL'] = 'redis://localhost:6379/0'
app.config['CELERY_RESULT_BACKEND'] = 'redis://localhost:6379/0'
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['WEBHOOK_SECRET'] = 'webhook-secret-key'

# Initialize Celery
celery = Celery(app.name, broker=app.config['CELERY_BROKER_URL'])
celery.conf.update(app.config)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def verify_signature(payload, signature, secret):
    """Verify webhook signature"""
    expected_signature = hmac.new(
        secret.encode(),
        payload.encode(),
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(signature, expected_signature)


@celery.task
def process_github_webhook(data):
    """Process GitHub webhook asynchronously"""
    logger.info(f"Processing GitHub webhook: {data.get('action', 'unknown')}")

    # Simulate processing
    event_type = data.get('action')
    repository = data.get('repository', {}).get('full_name', 'unknown')

    logger.info(f"GitHub event: {event_type} on {repository}")

    # Add your GitHub-specific processing logic here
    # For example: update database, send notifications, trigger CI/CD, etc.

    return {'status': 'success', 'event': event_type, 'repository': repository}


@celery.task
def process_stripe_webhook(data):
    """Process Stripe webhook asynchronously"""
    logger.info(f"Processing Stripe webhook: {data.get('type', 'unknown')}")

    event_type = data.get('type')
    event_id = data.get('id')

    logger.info(f"Stripe event: {event_type} (ID: {event_id})")

    # Add your Stripe-specific processing logic here
    # For example: update subscription status, process payments, etc.

    return {'status': 'success', 'event': event_type, 'id': event_id}


@celery.task
def process_generic_webhook(data):
    """Process generic webhook asynchronously"""
    logger.info(f"Processing generic webhook: {data}")

    # Add your generic processing logic here

    return {'status': 'success', 'processed_at': datetime.utcnow().isoformat()}


@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat()
    }), 200


@app.route('/webhooks/github', methods=['POST'])
def github_webhook():
    """Endpoint for GitHub webhooks"""
    # Get signature from headers
    signature = request.headers.get('X-Hub-Signature-256', '').replace('sha256=', '')

    # Get raw payload
    payload = request.get_data(as_text=True)

    # Verify signature
    if not verify_signature(payload, signature, app.config['WEBHOOK_SECRET']):
        logger.warning("Invalid GitHub webhook signature")
        return jsonify({'error': 'Invalid signature'}), 401

    # Parse JSON data
    data = request.get_json()

    # Queue task for async processing
    task = process_github_webhook.delay(data)

    logger.info(f"GitHub webhook queued: {task.id}")

    return jsonify({
        'status': 'accepted',
        'task_id': task.id
    }), 202


@app.route('/webhooks/stripe', methods=['POST'])
def stripe_webhook():
    """Endpoint for Stripe webhooks"""
    # Get signature from headers
    signature = request.headers.get('Stripe-Signature')

    # Get raw payload
    payload = request.get_data(as_text=True)

    # In production, use Stripe's library to verify webhook signature
    # For now, we'll do basic verification
    if not signature:
        logger.warning("Missing Stripe webhook signature")
        return jsonify({'error': 'Missing signature'}), 401

    # Parse JSON data
    data = request.get_json()

    # Queue task for async processing
    task = process_stripe_webhook.delay(data)

    logger.info(f"Stripe webhook queued: {task.id}")

    return jsonify({
        'status': 'accepted',
        'task_id': task.id
    }), 202


@app.route('/webhooks/generic', methods=['POST'])
def generic_webhook():
    """Endpoint for generic webhooks"""
    # Get optional API key from headers
    api_key = request.headers.get('X-API-Key')

    if not api_key:
        logger.warning("Missing API key")
        return jsonify({'error': 'Missing API key'}), 401

    # Basic API key validation
    if api_key != 'your-api-key-here':
        logger.warning("Invalid API key")
        return jsonify({'error': 'Invalid API key'}), 401

    # Parse JSON data
    data = request.get_json()

    if not data:
        return jsonify({'error': 'Invalid JSON payload'}), 400

    # Queue task for async processing
    task = process_generic_webhook.delay(data)

    logger.info(f"Generic webhook queued: {task.id}")

    return jsonify({
        'status': 'accepted',
        'task_id': task.id
    }), 202


@app.route('/webhooks/slack', methods=['POST'])
def slack_webhook():
    """Endpoint for Slack webhooks"""
    data = request.get_json()

    # Handle Slack URL verification challenge
    if data and data.get('type') == 'url_verification':
        return jsonify({'challenge': data.get('challenge')}), 200

    # Verify token
    token = data.get('token')
    if token != 'slack-verification-token':
        logger.warning("Invalid Slack token")
        return jsonify({'error': 'Invalid token'}), 401

    # Queue task for async processing
    task = process_generic_webhook.delay(data)

    logger.info(f"Slack webhook queued: {task.id}")

    return jsonify({
        'status': 'accepted',
        'task_id': task.id
    }), 202


@app.route('/tasks/<task_id>', methods=['GET'])
def get_task_status(task_id):
    """Get status of a queued task"""
    task = celery.AsyncResult(task_id)

    if task.state == 'PENDING':
        response = {
            'state': task.state,
            'status': 'Task is pending...'
        }
    elif task.state == 'SUCCESS':
        response = {
            'state': task.state,
            'result': task.result
        }
    elif task.state == 'FAILURE':
        response = {
            'state': task.state,
            'error': str(task.info)
        }
    else:
        response = {
            'state': task.state,
            'status': task.info
        }

    return jsonify(response), 200


@app.errorhandler(400)
def bad_request(error):
    return jsonify({'error': 'Bad request'}), 400


@app.errorhandler(401)
def unauthorized(error):
    return jsonify({'error': 'Unauthorized'}), 401


@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404


@app.errorhandler(500)
def internal_error(error):
    logger.error(f"Internal error: {error}")
    return jsonify({'error': 'Internal server error'}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
