import unittest
import json
import hmac
import hashlib
from app import app, celery


class WebhookTestCase(unittest.TestCase):
    """Test cases for webhook endpoints"""

    def setUp(self):
        """Set up test client"""
        self.app = app
        self.app.config['TESTING'] = True
        self.app.config['CELERY_TASK_ALWAYS_EAGER'] = True
        self.client = self.app.test_client()

    def test_health_check(self):
        """Test health check endpoint"""
        response = self.client.get('/health')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'healthy')

    def test_github_webhook_no_signature(self):
        """Test GitHub webhook without signature"""
        payload = {'action': 'opened', 'repository': {'full_name': 'test/repo'}}
        response = self.client.post(
            '/webhooks/github',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 401)

    def test_github_webhook_with_signature(self):
        """Test GitHub webhook with valid signature"""
        payload = {'action': 'opened', 'repository': {'full_name': 'test/repo'}}
        payload_str = json.dumps(payload)

        signature = hmac.new(
            app.config['WEBHOOK_SECRET'].encode(),
            payload_str.encode(),
            hashlib.sha256
        ).hexdigest()

        response = self.client.post(
            '/webhooks/github',
            data=payload_str,
            content_type='application/json',
            headers={'X-Hub-Signature-256': f'sha256={signature}'}
        )
        self.assertEqual(response.status_code, 202)
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'accepted')
        self.assertIn('task_id', data)

    def test_stripe_webhook_no_signature(self):
        """Test Stripe webhook without signature"""
        payload = {'type': 'payment_intent.succeeded', 'id': 'evt_123'}
        response = self.client.post(
            '/webhooks/stripe',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 401)

    def test_stripe_webhook_with_signature(self):
        """Test Stripe webhook with signature"""
        payload = {'type': 'payment_intent.succeeded', 'id': 'evt_123'}
        response = self.client.post(
            '/webhooks/stripe',
            data=json.dumps(payload),
            content_type='application/json',
            headers={'Stripe-Signature': 'test_signature'}
        )
        self.assertEqual(response.status_code, 202)

    def test_generic_webhook_no_api_key(self):
        """Test generic webhook without API key"""
        payload = {'event': 'test', 'data': {'message': 'Hello'}}
        response = self.client.post(
            '/webhooks/generic',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 401)

    def test_generic_webhook_with_api_key(self):
        """Test generic webhook with API key"""
        payload = {'event': 'test', 'data': {'message': 'Hello'}}
        response = self.client.post(
            '/webhooks/generic',
            data=json.dumps(payload),
            content_type='application/json',
            headers={'X-API-Key': 'your-api-key-here'}
        )
        self.assertEqual(response.status_code, 202)
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'accepted')

    def test_slack_url_verification(self):
        """Test Slack URL verification challenge"""
        payload = {
            'type': 'url_verification',
            'challenge': 'test_challenge_string'
        }
        response = self.client.post(
            '/webhooks/slack',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['challenge'], 'test_challenge_string')

    def test_slack_webhook_invalid_token(self):
        """Test Slack webhook with invalid token"""
        payload = {
            'type': 'event_callback',
            'token': 'invalid_token',
            'event': {'type': 'message'}
        }
        response = self.client.post(
            '/webhooks/slack',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 401)

    def test_generic_webhook_invalid_json(self):
        """Test generic webhook with invalid JSON"""
        response = self.client.post(
            '/webhooks/generic',
            data='invalid json',
            content_type='application/json',
            headers={'X-API-Key': 'your-api-key-here'}
        )
        self.assertEqual(response.status_code, 400)

    def test_task_status_endpoint(self):
        """Test task status endpoint"""
        response = self.client.get('/tasks/test-task-id')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('state', data)


if __name__ == '__main__':
    unittest.main()
