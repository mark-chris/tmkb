import io


def _register_and_login(client, username="alice", password="secret", org_name="Acme"):
    client.post(
        "/auth/register",
        json={"username": username, "password": password, "org_name": org_name},
    )
    client.post("/auth/login", json={"username": username, "password": password})


def test_upload_file(client, db):
    _register_and_login(client)
    data = {"file": (io.BytesIO(b"hello world"), "test.txt")}
    resp = client.post("/files/upload", data=data, content_type="multipart/form-data")
    assert resp.status_code == 201
    body = resp.get_json()
    assert body["filename"] == "test.txt"
    assert body["status"] == "pending"


def test_upload_requires_auth(client):
    data = {"file": (io.BytesIO(b"hello"), "test.txt")}
    resp = client.post("/files/upload", data=data, content_type="multipart/form-data")
    assert resp.status_code == 401


def test_upload_no_file(client, db):
    _register_and_login(client)
    resp = client.post("/files/upload", data={}, content_type="multipart/form-data")
    assert resp.status_code == 400


def test_list_files(client, db):
    _register_and_login(client)
    data = {"file": (io.BytesIO(b"content"), "a.txt")}
    client.post("/files/upload", data=data, content_type="multipart/form-data")
    data2 = {"file": (io.BytesIO(b"content2"), "b.txt")}
    client.post("/files/upload", data=data2, content_type="multipart/form-data")

    resp = client.get("/files/")
    assert resp.status_code == 200
    body = resp.get_json()
    assert len(body["files"]) == 2


def test_get_file(client, db):
    _register_and_login(client)
    data = {"file": (io.BytesIO(b"content"), "report.txt")}
    upload_resp = client.post(
        "/files/upload", data=data, content_type="multipart/form-data"
    )
    file_id = upload_resp.get_json()["id"]

    resp = client.get(f"/files/{file_id}")
    assert resp.status_code == 200
    assert resp.get_json()["filename"] == "report.txt"


def test_get_file_not_found(client, db):
    _register_and_login(client)
    resp = client.get("/files/9999")
    assert resp.status_code == 404


def test_cross_org_isolation(client, db):
    # Org 1 uploads a file
    _register_and_login(client, "alice", "pw", "Org1")
    data = {"file": (io.BytesIO(b"secret"), "org1_file.txt")}
    upload_resp = client.post(
        "/files/upload", data=data, content_type="multipart/form-data"
    )
    file_id = upload_resp.get_json()["id"]
    client.post("/auth/logout")

    # Org 2 cannot see Org 1's file
    _register_and_login(client, "bob", "pw", "Org2")
    resp = client.get(f"/files/{file_id}")
    assert resp.status_code == 404

    list_resp = client.get("/files/")
    assert len(list_resp.get_json()["files"]) == 0
