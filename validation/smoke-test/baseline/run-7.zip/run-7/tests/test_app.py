def test_app_creates(app):
    assert app is not None
    assert app.config["TESTING"] is True
