from app.models.file import UploadedFile
from app.models.organization import Organization
from app.models.user import User


def test_create_uploaded_file(db):
    org = Organization(name="Acme")
    db.session.add(org)
    db.session.flush()

    user = User(username="alice", org_id=org.id)
    user.set_password("pw")
    db.session.add(user)
    db.session.flush()

    f = UploadedFile(
        filename="report.pdf",
        stored_path="/uploads/1/abc_report.pdf",
        size_bytes=1024,
        content_type="application/pdf",
        org_id=org.id,
        uploaded_by=user.id,
    )
    db.session.add(f)
    db.session.commit()

    assert f.id is not None
    assert f.status == "pending"
    assert f.created_at is not None
    assert f.processed_at is None


def test_file_belongs_to_org(db):
    org = Organization(name="Acme")
    db.session.add(org)
    db.session.flush()

    user = User(username="alice", org_id=org.id)
    user.set_password("pw")
    db.session.add(user)
    db.session.flush()

    f = UploadedFile(
        filename="data.csv",
        stored_path="/uploads/1/xyz_data.csv",
        size_bytes=512,
        content_type="text/csv",
        org_id=org.id,
        uploaded_by=user.id,
    )
    db.session.add(f)
    db.session.commit()

    assert f.organization.name == "Acme"
    assert f.uploader.username == "alice"
