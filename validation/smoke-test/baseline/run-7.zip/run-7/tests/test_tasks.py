from app.models.file import UploadedFile
from app.models.organization import Organization
from app.models.user import User


def test_process_file_sets_completed(app, db):
    org = Organization(name="Acme")
    db.session.add(org)
    db.session.flush()

    user = User(username="alice", org_id=org.id)
    user.set_password("pw")
    db.session.add(user)
    db.session.flush()

    f = UploadedFile(
        filename="test.txt",
        stored_path="/tmp/test_uploads/1/test.txt",
        size_bytes=100,
        content_type="text/plain",
        org_id=org.id,
        uploaded_by=user.id,
    )
    db.session.add(f)
    db.session.commit()

    from app.tasks import process_file

    result = process_file.apply(args=[f.id])
    result.get()

    db.session.refresh(f)
    assert f.status == "completed"
    assert f.processed_at is not None


def test_process_file_nonexistent_id(app, db):
    from app.tasks import process_file

    result = process_file.apply(args=[9999])
    result.get()
    # Should not raise; just logs and returns
