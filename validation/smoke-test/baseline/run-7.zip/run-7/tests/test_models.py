from app.models.organization import Organization
from app.models.user import User


def test_create_organization(db):
    org = Organization(name="Acme Corp")
    db.session.add(org)
    db.session.commit()

    assert org.id is not None
    assert org.name == "Acme Corp"
    assert org.created_at is not None


def test_create_user(db):
    org = Organization(name="Acme Corp")
    db.session.add(org)
    db.session.commit()

    user = User(username="alice", org_id=org.id)
    user.set_password("secret123")
    db.session.add(user)
    db.session.commit()

    assert user.id is not None
    assert user.org_id == org.id
    assert user.check_password("secret123")
    assert not user.check_password("wrong")


def test_user_org_relationship(db):
    org = Organization(name="Acme Corp")
    db.session.add(org)
    db.session.commit()

    user = User(username="alice", org_id=org.id)
    user.set_password("pw")
    db.session.add(user)
    db.session.commit()

    assert user.organization.name == "Acme Corp"
    assert org.users[0].username == "alice"


def test_username_unique(db):
    import sqlalchemy
    org = Organization(name="Acme Corp")
    db.session.add(org)
    db.session.commit()

    u1 = User(username="alice", org_id=org.id)
    u1.set_password("pw")
    db.session.add(u1)
    db.session.commit()

    u2 = User(username="alice", org_id=org.id)
    u2.set_password("pw2")
    db.session.add(u2)
    try:
        db.session.commit()
        assert False, "Should have raised IntegrityError"
    except sqlalchemy.exc.IntegrityError:
        db.session.rollback()
