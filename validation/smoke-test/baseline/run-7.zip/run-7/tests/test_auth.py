import json


def test_register_creates_user_and_org(client, db):
    resp = client.post(
        "/auth/register",
        json={"username": "alice", "password": "secret123", "org_name": "Acme Corp"},
    )
    assert resp.status_code == 201
    data = resp.get_json()
    assert data["username"] == "alice"
    assert data["org_name"] == "Acme Corp"


def test_register_missing_fields(client):
    resp = client.post("/auth/register", json={"username": "alice"})
    assert resp.status_code == 400


def test_register_duplicate_username(client, db):
    client.post(
        "/auth/register",
        json={"username": "alice", "password": "pw", "org_name": "Org1"},
    )
    resp = client.post(
        "/auth/register",
        json={"username": "alice", "password": "pw2", "org_name": "Org2"},
    )
    assert resp.status_code == 409


def test_login_success(client, db):
    client.post(
        "/auth/register",
        json={"username": "alice", "password": "secret", "org_name": "Acme"},
    )
    resp = client.post(
        "/auth/login", json={"username": "alice", "password": "secret"}
    )
    assert resp.status_code == 200
    assert resp.get_json()["username"] == "alice"


def test_login_bad_password(client, db):
    client.post(
        "/auth/register",
        json={"username": "alice", "password": "secret", "org_name": "Acme"},
    )
    resp = client.post(
        "/auth/login", json={"username": "alice", "password": "wrong"}
    )
    assert resp.status_code == 401


def test_logout(client, db):
    client.post(
        "/auth/register",
        json={"username": "alice", "password": "secret", "org_name": "Acme"},
    )
    client.post("/auth/login", json={"username": "alice", "password": "secret"})
    resp = client.post("/auth/logout")
    assert resp.status_code == 200
