# Flask Multi-Tenant SaaS API Design

## Overview

A Flask REST API for a multi-tenant SaaS with background job processing for file uploads. Users belong to organizations. Files are scoped per-organization. Celery handles async processing.

## Decisions

- **Architecture**: Application factory pattern with blueprints (auth, files)
- **Database**: SQLite via SQLAlchemy
- **Auth**: Session-based with Flask-Login, password hashing via werkzeug
- **File storage**: Local filesystem under `uploads/<org_id>/`
- **Background jobs**: Celery with Redis broker
- **Multi-tenancy**: Row-level filtering by org_id on all file queries
- **File processing**: Lightweight placeholder (file size check, simulated processing)

## Project Structure

```
app/
├── __init__.py          # create_app() factory
├── extensions.py        # db, login_manager, celery init
├── models/
│   ├── __init__.py
│   ├── organization.py  # Organization model
│   ├── user.py          # User model (belongs to org)
│   └── file.py          # UploadedFile model
├── blueprints/
│   ├── __init__.py
│   ├── auth.py          # register, login, logout
│   └── files.py         # upload, list, get
└── tasks.py             # Celery tasks (process_file)
config.py
celery_worker.py
requirements.txt
run.py
```

## Data Models

### Organization
- id (PK), name, created_at

### User
- id (PK), username (unique), password_hash, org_id (FK → Organization), created_at

### UploadedFile
- id (PK), filename, stored_path, size_bytes, content_type
- status: pending → processing → completed | failed
- org_id (FK → Organization), uploaded_by (FK → User)
- created_at, processed_at

## API Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | /auth/register | No | Register user with org name |
| POST | /auth/login | No | Login, starts session |
| POST | /auth/logout | Yes | Logout |
| POST | /files/upload | Yes | Upload file, dispatches Celery task |
| GET | /files/ | Yes | List files for user's org |
| GET | /files/<id> | Yes | Get file metadata + processing status |

## Upload Flow

1. User POSTs file to /files/upload
2. File saved to `uploads/<org_id>/<uuid>_<original_filename>`
3. UploadedFile record created with status=pending
4. Celery task `process_file(file_id)` dispatched
5. Task: sets status=processing, does placeholder work, sets status=completed/failed

## Multi-Tenancy

All UploadedFile queries filter by `org_id == current_user.org_id`. No cross-org data access. Users see only their organization's files.

## Authentication

- Flask-Login with server-side sessions
- Passwords hashed with werkzeug.security (pbkdf2)
- @login_required decorator on protected endpoints
- All responses are JSON (no HTML)
