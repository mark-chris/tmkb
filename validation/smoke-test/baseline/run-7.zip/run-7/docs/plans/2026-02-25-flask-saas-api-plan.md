# Flask Multi-Tenant SaaS API Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a Flask REST API with multi-tenant file uploads, session auth, and Celery background processing.

**Architecture:** Application factory with blueprints (auth, files). SQLAlchemy models with row-level tenant isolation via org_id. Celery worker processes uploaded files asynchronously.

**Tech Stack:** Flask, Flask-Login, Flask-SQLAlchemy, Celery, Redis, SQLite, pytest

---

### Task 1: Project Scaffolding and Dependencies

**Files:**
- Create: `requirements.txt`
- Create: `config.py`
- Create: `app/__init__.py`
- Create: `app/extensions.py`
- Create: `app/models/__init__.py`
- Create: `app/blueprints/__init__.py`
- Create: `run.py`
- Create: `tests/__init__.py`
- Create: `tests/conftest.py`

**Step 1: Create requirements.txt**

```
Flask==3.1.0
Flask-Login==0.6.3
Flask-SQLAlchemy==3.1.1
celery[redis]==5.4.0
pytest==8.3.4
werkzeug==3.1.3
```

**Step 2: Create virtual environment and install dependencies**

Run:
```bash
cd /home/mark/Projects/flask-api-opus46-extended
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```
Expected: All packages install successfully.

**Step 3: Create config.py**

```python
import os

basedir = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key-change-in-production")
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(basedir, 'app.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.path.join(basedir, "uploads")
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max upload
    CELERY_BROKER_URL = os.environ.get("CELERY_BROKER_URL", "redis://localhost:6379/0")
    CELERY_RESULT_BACKEND = os.environ.get(
        "CELERY_RESULT_BACKEND", "redis://localhost:6379/0"
    )


class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    UPLOAD_FOLDER = "/tmp/test_uploads"
    CELERY_BROKER_URL = "memory://"
    CELERY_RESULT_BACKEND = "cache+memory://"
    CELERY_TASK_ALWAYS_EAGER = True
    CELERY_TASK_EAGER_PROPAGATES = True
```

**Step 4: Create app/extensions.py**

```python
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
login_manager = LoginManager()
```

**Step 5: Create app/__init__.py (application factory)**

```python
import os

from celery import Celery
from flask import Flask

from app.extensions import db, login_manager
from config import Config

celery = Celery(__name__)


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    login_manager.init_app(app)

    celery.conf.update(
        broker_url=app.config["CELERY_BROKER_URL"],
        result_backend=app.config["CELERY_RESULT_BACKEND"],
        task_always_eager=app.config.get("CELERY_TASK_ALWAYS_EAGER", False),
        task_eager_propagates=app.config.get("CELERY_TASK_EAGER_PROPAGATES", False),
    )

    class ContextTask(celery.Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)

    celery.Task = ContextTask

    from app.blueprints.auth import auth_bp
    from app.blueprints.files import files_bp

    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(files_bp, url_prefix="/files")

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    with app.app_context():
        db.create_all()

    return app
```

**Step 6: Create empty __init__.py files**

Create empty files:
- `app/models/__init__.py`
- `app/blueprints/__init__.py`
- `tests/__init__.py`

**Step 7: Create stub blueprints so the factory can import them**

Create `app/blueprints/auth.py`:
```python
from flask import Blueprint

auth_bp = Blueprint("auth", __name__)
```

Create `app/blueprints/files.py`:
```python
from flask import Blueprint

files_bp = Blueprint("files", __name__)
```

**Step 8: Create run.py**

```python
from app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
```

**Step 9: Create tests/conftest.py**

```python
import os
import shutil

import pytest

from app import create_app
from app.extensions import db as _db
from config import TestConfig


@pytest.fixture
def app():
    app = create_app(TestConfig)
    with app.app_context():
        _db.create_all()
        yield app
        _db.session.remove()
        _db.drop_all()
    upload_dir = app.config["UPLOAD_FOLDER"]
    if os.path.exists(upload_dir):
        shutil.rmtree(upload_dir)


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def db(app):
    return _db
```

**Step 10: Write a smoke test**

Create `tests/test_app.py`:
```python
def test_app_creates(app):
    assert app is not None
    assert app.config["TESTING"] is True
```

**Step 11: Run the smoke test**

Run: `cd /home/mark/Projects/flask-api-opus46-extended && source venv/bin/activate && pytest tests/test_app.py -v`
Expected: 1 test passes.

**Step 12: Commit**

```bash
git init
git add requirements.txt config.py run.py app/ tests/
git commit -m "feat: project scaffolding with app factory, config, and test fixtures"
```

---

### Task 2: Organization and User Models

**Files:**
- Create: `app/models/organization.py`
- Create: `app/models/user.py`
- Modify: `app/models/__init__.py`
- Modify: `app/extensions.py` (add user_loader)
- Create: `tests/test_models.py`

**Step 1: Write failing tests for models**

Create `tests/test_models.py`:
```python
from app.models.organization import Organization
from app.models.user import User


def test_create_organization(db):
    org = Organization(name="Acme Corp")
    db.session.add(org)
    db.session.commit()

    assert org.id is not None
    assert org.name == "Acme Corp"
    assert org.created_at is not None


def test_create_user(db):
    org = Organization(name="Acme Corp")
    db.session.add(org)
    db.session.commit()

    user = User(username="alice", org_id=org.id)
    user.set_password("secret123")
    db.session.add(user)
    db.session.commit()

    assert user.id is not None
    assert user.org_id == org.id
    assert user.check_password("secret123")
    assert not user.check_password("wrong")


def test_user_org_relationship(db):
    org = Organization(name="Acme Corp")
    db.session.add(org)
    db.session.commit()

    user = User(username="alice", org_id=org.id)
    user.set_password("pw")
    db.session.add(user)
    db.session.commit()

    assert user.organization.name == "Acme Corp"
    assert org.users[0].username == "alice"


def test_username_unique(db):
    import sqlalchemy
    org = Organization(name="Acme Corp")
    db.session.add(org)
    db.session.commit()

    u1 = User(username="alice", org_id=org.id)
    u1.set_password("pw")
    db.session.add(u1)
    db.session.commit()

    u2 = User(username="alice", org_id=org.id)
    u2.set_password("pw2")
    db.session.add(u2)
    try:
        db.session.commit()
        assert False, "Should have raised IntegrityError"
    except sqlalchemy.exc.IntegrityError:
        db.session.rollback()
```

**Step 2: Run tests to verify they fail**

Run: `pytest tests/test_models.py -v`
Expected: All 4 tests FAIL (models don't exist yet).

**Step 3: Create Organization model**

Create `app/models/organization.py`:
```python
from datetime import datetime, timezone

from app.extensions import db


class Organization(db.Model):
    __tablename__ = "organizations"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)
    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )

    users = db.relationship("User", backref="organization", lazy=True)
    files = db.relationship("UploadedFile", backref="organization", lazy=True)
```

**Step 4: Create User model**

Create `app/models/user.py`:
```python
from datetime import datetime, timezone

from flask_login import UserMixin
from werkzeug.security import check_password_hash, generate_password_hash

from app.extensions import db


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )

    files = db.relationship("UploadedFile", backref="uploader", lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
```

**Step 5: Update app/models/__init__.py**

```python
from app.models.organization import Organization
from app.models.user import User
```

**Step 6: Add user_loader to app/extensions.py**

Replace `app/extensions.py` with:
```python
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
login_manager = LoginManager()


@login_manager.user_loader
def load_user(user_id):
    from app.models.user import User

    return db.session.get(User, int(user_id))


@login_manager.unauthorized_handler
def unauthorized():
    from flask import jsonify

    return jsonify({"error": "Authentication required"}), 401
```

**Step 7: Run tests**

Run: `pytest tests/test_models.py -v`
Expected: All 4 tests PASS.

**Step 8: Commit**

```bash
git add app/models/ app/extensions.py tests/test_models.py
git commit -m "feat: Organization and User models with password hashing"
```

---

### Task 3: Auth Blueprint (Register, Login, Logout)

**Files:**
- Modify: `app/blueprints/auth.py`
- Create: `tests/test_auth.py`

**Step 1: Write failing tests for auth endpoints**

Create `tests/test_auth.py`:
```python
import json


def test_register_creates_user_and_org(client, db):
    resp = client.post(
        "/auth/register",
        json={"username": "alice", "password": "secret123", "org_name": "Acme Corp"},
    )
    assert resp.status_code == 201
    data = resp.get_json()
    assert data["username"] == "alice"
    assert data["org_name"] == "Acme Corp"


def test_register_missing_fields(client):
    resp = client.post("/auth/register", json={"username": "alice"})
    assert resp.status_code == 400


def test_register_duplicate_username(client, db):
    client.post(
        "/auth/register",
        json={"username": "alice", "password": "pw", "org_name": "Org1"},
    )
    resp = client.post(
        "/auth/register",
        json={"username": "alice", "password": "pw2", "org_name": "Org2"},
    )
    assert resp.status_code == 409


def test_login_success(client, db):
    client.post(
        "/auth/register",
        json={"username": "alice", "password": "secret", "org_name": "Acme"},
    )
    resp = client.post(
        "/auth/login", json={"username": "alice", "password": "secret"}
    )
    assert resp.status_code == 200
    assert resp.get_json()["username"] == "alice"


def test_login_bad_password(client, db):
    client.post(
        "/auth/register",
        json={"username": "alice", "password": "secret", "org_name": "Acme"},
    )
    resp = client.post(
        "/auth/login", json={"username": "alice", "password": "wrong"}
    )
    assert resp.status_code == 401


def test_logout(client, db):
    client.post(
        "/auth/register",
        json={"username": "alice", "password": "secret", "org_name": "Acme"},
    )
    client.post("/auth/login", json={"username": "alice", "password": "secret"})
    resp = client.post("/auth/logout")
    assert resp.status_code == 200
```

**Step 2: Run tests to verify they fail**

Run: `pytest tests/test_auth.py -v`
Expected: All 6 tests FAIL.

**Step 3: Implement auth blueprint**

Replace `app/blueprints/auth.py` with:
```python
from flask import Blueprint, jsonify, request
from flask_login import current_user, login_required, login_user, logout_user

from app.extensions import db
from app.models.organization import Organization
from app.models.user import User

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json()
    if not data or not all(k in data for k in ("username", "password", "org_name")):
        return jsonify({"error": "username, password, and org_name are required"}), 400

    if User.query.filter_by(username=data["username"]).first():
        return jsonify({"error": "Username already taken"}), 409

    org = Organization(name=data["org_name"])
    db.session.add(org)
    db.session.flush()

    user = User(username=data["username"], org_id=org.id)
    user.set_password(data["password"])
    db.session.add(user)
    db.session.commit()

    return jsonify({"id": user.id, "username": user.username, "org_name": org.name}), 201


@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    if not data or not all(k in data for k in ("username", "password")):
        return jsonify({"error": "username and password are required"}), 400

    user = User.query.filter_by(username=data["username"]).first()
    if not user or not user.check_password(data["password"]):
        return jsonify({"error": "Invalid credentials"}), 401

    login_user(user)
    return jsonify({"id": user.id, "username": user.username, "org_id": user.org_id}), 200


@auth_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    return jsonify({"message": "Logged out"}), 200
```

**Step 4: Run tests**

Run: `pytest tests/test_auth.py -v`
Expected: All 6 tests PASS.

**Step 5: Commit**

```bash
git add app/blueprints/auth.py tests/test_auth.py
git commit -m "feat: auth blueprint with register, login, logout endpoints"
```

---

### Task 4: UploadedFile Model

**Files:**
- Create: `app/models/file.py`
- Modify: `app/models/__init__.py`
- Create: `tests/test_file_model.py`

**Step 1: Write failing tests**

Create `tests/test_file_model.py`:
```python
from app.models.file import UploadedFile
from app.models.organization import Organization
from app.models.user import User


def test_create_uploaded_file(db):
    org = Organization(name="Acme")
    db.session.add(org)
    db.session.flush()

    user = User(username="alice", org_id=org.id)
    user.set_password("pw")
    db.session.add(user)
    db.session.flush()

    f = UploadedFile(
        filename="report.pdf",
        stored_path="/uploads/1/abc_report.pdf",
        size_bytes=1024,
        content_type="application/pdf",
        org_id=org.id,
        uploaded_by=user.id,
    )
    db.session.add(f)
    db.session.commit()

    assert f.id is not None
    assert f.status == "pending"
    assert f.created_at is not None
    assert f.processed_at is None


def test_file_belongs_to_org(db):
    org = Organization(name="Acme")
    db.session.add(org)
    db.session.flush()

    user = User(username="alice", org_id=org.id)
    user.set_password("pw")
    db.session.add(user)
    db.session.flush()

    f = UploadedFile(
        filename="data.csv",
        stored_path="/uploads/1/xyz_data.csv",
        size_bytes=512,
        content_type="text/csv",
        org_id=org.id,
        uploaded_by=user.id,
    )
    db.session.add(f)
    db.session.commit()

    assert f.organization.name == "Acme"
    assert f.uploader.username == "alice"
```

**Step 2: Run tests to verify they fail**

Run: `pytest tests/test_file_model.py -v`
Expected: FAIL (UploadedFile doesn't exist).

**Step 3: Create UploadedFile model**

Create `app/models/file.py`:
```python
from datetime import datetime, timezone

from app.extensions import db


class UploadedFile(db.Model):
    __tablename__ = "uploaded_files"

    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(256), nullable=False)
    stored_path = db.Column(db.String(512), nullable=False)
    size_bytes = db.Column(db.Integer, nullable=False)
    content_type = db.Column(db.String(128), nullable=False)
    status = db.Column(db.String(20), default="pending", nullable=False)
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    uploaded_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    processed_at = db.Column(db.DateTime, nullable=True)
```

**Step 4: Update app/models/__init__.py**

```python
from app.models.file import UploadedFile
from app.models.organization import Organization
from app.models.user import User
```

**Step 5: Run tests**

Run: `pytest tests/test_file_model.py -v`
Expected: 2 tests PASS.

**Step 6: Commit**

```bash
git add app/models/file.py app/models/__init__.py tests/test_file_model.py
git commit -m "feat: UploadedFile model with status tracking"
```

---

### Task 5: Celery Task (process_file)

**Files:**
- Create: `app/tasks.py`
- Create: `celery_worker.py`
- Create: `tests/test_tasks.py`

**Step 1: Write failing test for the Celery task**

Create `tests/test_tasks.py`:
```python
from app.models.file import UploadedFile
from app.models.organization import Organization
from app.models.user import User


def test_process_file_sets_completed(app, db):
    org = Organization(name="Acme")
    db.session.add(org)
    db.session.flush()

    user = User(username="alice", org_id=org.id)
    user.set_password("pw")
    db.session.add(user)
    db.session.flush()

    f = UploadedFile(
        filename="test.txt",
        stored_path="/tmp/test_uploads/1/test.txt",
        size_bytes=100,
        content_type="text/plain",
        org_id=org.id,
        uploaded_by=user.id,
    )
    db.session.add(f)
    db.session.commit()

    from app.tasks import process_file

    result = process_file.apply(args=[f.id])
    result.get()

    db.session.refresh(f)
    assert f.status == "completed"
    assert f.processed_at is not None


def test_process_file_nonexistent_id(app, db):
    from app.tasks import process_file

    result = process_file.apply(args=[9999])
    result.get()
    # Should not raise; just logs and returns
```

**Step 2: Run tests to verify they fail**

Run: `pytest tests/test_tasks.py -v`
Expected: FAIL (tasks module doesn't exist).

**Step 3: Create app/tasks.py**

```python
import logging
import os
from datetime import datetime, timezone

from app import celery
from app.extensions import db
from app.models.file import UploadedFile

logger = logging.getLogger(__name__)


@celery.task
def process_file(file_id):
    uploaded_file = db.session.get(UploadedFile, file_id)
    if not uploaded_file:
        logger.warning("File %d not found, skipping", file_id)
        return

    uploaded_file.status = "processing"
    db.session.commit()

    try:
        # Placeholder processing: verify file exists and check size
        if os.path.exists(uploaded_file.stored_path):
            actual_size = os.path.getsize(uploaded_file.stored_path)
            logger.info(
                "Processed file %s (%d bytes)", uploaded_file.filename, actual_size
            )
        else:
            logger.info(
                "File path not found on disk, marking complete anyway: %s",
                uploaded_file.stored_path,
            )

        uploaded_file.status = "completed"
        uploaded_file.processed_at = datetime.now(timezone.utc)
        db.session.commit()

    except Exception:
        logger.exception("Failed to process file %d", file_id)
        uploaded_file.status = "failed"
        db.session.commit()
```

**Step 4: Create celery_worker.py**

```python
from app import celery, create_app

app = create_app()
app.app_context().push()
```

**Step 5: Run tests**

Run: `pytest tests/test_tasks.py -v`
Expected: 2 tests PASS.

**Step 6: Commit**

```bash
git add app/tasks.py celery_worker.py tests/test_tasks.py
git commit -m "feat: Celery process_file task with placeholder processing"
```

---

### Task 6: Files Blueprint (Upload, List, Get)

**Files:**
- Modify: `app/blueprints/files.py`
- Create: `tests/test_files.py`

**Step 1: Write failing tests**

Create `tests/test_files.py`:
```python
import io


def _register_and_login(client, username="alice", password="secret", org_name="Acme"):
    client.post(
        "/auth/register",
        json={"username": username, "password": password, "org_name": org_name},
    )
    client.post("/auth/login", json={"username": username, "password": password})


def test_upload_file(client, db):
    _register_and_login(client)
    data = {"file": (io.BytesIO(b"hello world"), "test.txt")}
    resp = client.post("/files/upload", data=data, content_type="multipart/form-data")
    assert resp.status_code == 201
    body = resp.get_json()
    assert body["filename"] == "test.txt"
    assert body["status"] == "pending"


def test_upload_requires_auth(client):
    data = {"file": (io.BytesIO(b"hello"), "test.txt")}
    resp = client.post("/files/upload", data=data, content_type="multipart/form-data")
    assert resp.status_code == 401


def test_upload_no_file(client, db):
    _register_and_login(client)
    resp = client.post("/files/upload", data={}, content_type="multipart/form-data")
    assert resp.status_code == 400


def test_list_files(client, db):
    _register_and_login(client)
    data = {"file": (io.BytesIO(b"content"), "a.txt")}
    client.post("/files/upload", data=data, content_type="multipart/form-data")
    data2 = {"file": (io.BytesIO(b"content2"), "b.txt")}
    client.post("/files/upload", data=data2, content_type="multipart/form-data")

    resp = client.get("/files/")
    assert resp.status_code == 200
    body = resp.get_json()
    assert len(body["files"]) == 2


def test_get_file(client, db):
    _register_and_login(client)
    data = {"file": (io.BytesIO(b"content"), "report.txt")}
    upload_resp = client.post(
        "/files/upload", data=data, content_type="multipart/form-data"
    )
    file_id = upload_resp.get_json()["id"]

    resp = client.get(f"/files/{file_id}")
    assert resp.status_code == 200
    assert resp.get_json()["filename"] == "report.txt"


def test_get_file_not_found(client, db):
    _register_and_login(client)
    resp = client.get("/files/9999")
    assert resp.status_code == 404


def test_cross_org_isolation(client, db):
    # Org 1 uploads a file
    _register_and_login(client, "alice", "pw", "Org1")
    data = {"file": (io.BytesIO(b"secret"), "org1_file.txt")}
    upload_resp = client.post(
        "/files/upload", data=data, content_type="multipart/form-data"
    )
    file_id = upload_resp.get_json()["id"]
    client.post("/auth/logout")

    # Org 2 cannot see Org 1's file
    _register_and_login(client, "bob", "pw", "Org2")
    resp = client.get(f"/files/{file_id}")
    assert resp.status_code == 404

    list_resp = client.get("/files/")
    assert len(list_resp.get_json()["files"]) == 0
```

**Step 2: Run tests to verify they fail**

Run: `pytest tests/test_files.py -v`
Expected: All 7 tests FAIL.

**Step 3: Implement files blueprint**

Replace `app/blueprints/files.py` with:
```python
import os
import uuid

from flask import Blueprint, current_app, jsonify, request
from flask_login import current_user, login_required

from app.extensions import db
from app.models.file import UploadedFile

files_bp = Blueprint("files", __name__)


@files_bp.route("/upload", methods=["POST"])
@login_required
def upload():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    org_dir = os.path.join(
        current_app.config["UPLOAD_FOLDER"], str(current_user.org_id)
    )
    os.makedirs(org_dir, exist_ok=True)

    unique_name = f"{uuid.uuid4().hex}_{file.filename}"
    stored_path = os.path.join(org_dir, unique_name)
    file.save(stored_path)

    size_bytes = os.path.getsize(stored_path)

    uploaded_file = UploadedFile(
        filename=file.filename,
        stored_path=stored_path,
        size_bytes=size_bytes,
        content_type=file.content_type or "application/octet-stream",
        org_id=current_user.org_id,
        uploaded_by=current_user.id,
    )
    db.session.add(uploaded_file)
    db.session.commit()

    from app.tasks import process_file

    process_file.delay(uploaded_file.id)

    return jsonify(
        {
            "id": uploaded_file.id,
            "filename": uploaded_file.filename,
            "size_bytes": uploaded_file.size_bytes,
            "status": uploaded_file.status,
        }
    ), 201


@files_bp.route("/", methods=["GET"])
@login_required
def list_files():
    files = UploadedFile.query.filter_by(org_id=current_user.org_id).all()
    return jsonify(
        {
            "files": [
                {
                    "id": f.id,
                    "filename": f.filename,
                    "size_bytes": f.size_bytes,
                    "content_type": f.content_type,
                    "status": f.status,
                    "created_at": f.created_at.isoformat(),
                    "processed_at": f.processed_at.isoformat()
                    if f.processed_at
                    else None,
                }
                for f in files
            ]
        }
    ), 200


@files_bp.route("/<int:file_id>", methods=["GET"])
@login_required
def get_file(file_id):
    uploaded_file = UploadedFile.query.filter_by(
        id=file_id, org_id=current_user.org_id
    ).first()
    if not uploaded_file:
        return jsonify({"error": "File not found"}), 404

    return jsonify(
        {
            "id": uploaded_file.id,
            "filename": uploaded_file.filename,
            "size_bytes": uploaded_file.size_bytes,
            "content_type": uploaded_file.content_type,
            "status": uploaded_file.status,
            "uploaded_by": uploaded_file.uploaded_by,
            "created_at": uploaded_file.created_at.isoformat(),
            "processed_at": uploaded_file.processed_at.isoformat()
            if uploaded_file.processed_at
            else None,
        }
    ), 200
```

**Step 4: Run tests**

Run: `pytest tests/test_files.py -v`
Expected: All 7 tests PASS.

**Step 5: Run full test suite**

Run: `pytest tests/ -v`
Expected: All tests PASS (smoke + models + auth + file model + tasks + files).

**Step 6: Commit**

```bash
git add app/blueprints/files.py tests/test_files.py
git commit -m "feat: files blueprint with upload, list, get, and cross-org isolation"
```

---

### Task 7: Final Verification

**Step 1: Run full test suite one final time**

Run: `pytest tests/ -v`
Expected: All tests PASS.

**Step 2: Verify app starts**

Run: `cd /home/mark/Projects/flask-api-opus46-extended && source venv/bin/activate && python -c "from app import create_app; app = create_app(); print('App created OK')" `
Expected: Prints "App created OK".

**Step 3: Final commit if any uncommitted changes**

```bash
git status
```
