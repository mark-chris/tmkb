import os

from celery import Celery
from flask import Flask, has_app_context

from app.extensions import db, login_manager
from config import Config

celery = Celery(__name__)


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    login_manager.init_app(app)

    celery.conf.update(
        broker_url=app.config["CELERY_BROKER_URL"],
        result_backend=app.config["CELERY_RESULT_BACKEND"],
        task_always_eager=app.config.get("CELERY_TASK_ALWAYS_EAGER", False),
        task_eager_propagates=app.config.get("CELERY_TASK_EAGER_PROPAGATES", False),
    )

    class ContextTask(celery.Task):
        def __call__(self, *args, **kwargs):
            if has_app_context():
                # Already inside an app context (e.g. eager mode in tests)
                return self.run(*args, **kwargs)
            with app.app_context():
                return self.run(*args, **kwargs)

    celery.Task = ContextTask

    from app.blueprints.auth import auth_bp
    from app.blueprints.files import files_bp

    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(files_bp, url_prefix="/files")

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    with app.app_context():
        db.create_all()

    return app
