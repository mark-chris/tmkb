import logging
import os
from datetime import datetime, timezone

from app import celery
from app.extensions import db
from app.models.file import UploadedFile

logger = logging.getLogger(__name__)


@celery.task
def process_file(file_id):
    uploaded_file = db.session.get(UploadedFile, file_id)
    if not uploaded_file:
        logger.warning("File %d not found, skipping", file_id)
        return

    uploaded_file.status = "processing"
    db.session.commit()

    try:
        # Placeholder processing: verify file exists and check size
        if os.path.exists(uploaded_file.stored_path):
            actual_size = os.path.getsize(uploaded_file.stored_path)
            logger.info(
                "Processed file %s (%d bytes)", uploaded_file.filename, actual_size
            )
        else:
            logger.info(
                "File path not found on disk, marking complete anyway: %s",
                uploaded_file.stored_path,
            )

        uploaded_file.status = "completed"
        uploaded_file.processed_at = datetime.now(timezone.utc)
        db.session.commit()

    except Exception:
        logger.exception("Failed to process file %d", file_id)
        uploaded_file.status = "failed"
        db.session.commit()
