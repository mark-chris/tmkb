from datetime import datetime, timezone

from app.extensions import db


class UploadedFile(db.Model):
    __tablename__ = "uploaded_files"

    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(256), nullable=False)
    stored_path = db.Column(db.String(512), nullable=False)
    size_bytes = db.Column(db.Integer, nullable=False)
    content_type = db.Column(db.String(128), nullable=False)
    status = db.Column(db.String(20), default="pending", nullable=False)
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    uploaded_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    processed_at = db.Column(db.DateTime, nullable=True)

    organization = db.relationship("Organization", back_populates="files")
    uploader = db.relationship("User", back_populates="files")
