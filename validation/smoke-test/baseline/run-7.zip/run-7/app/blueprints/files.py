import os
import uuid

from flask import Blueprint, current_app, jsonify, request
from flask_login import current_user, login_required

from app.extensions import db
from app.models.file import UploadedFile

files_bp = Blueprint("files", __name__)


@files_bp.route("/upload", methods=["POST"])
@login_required
def upload():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    org_dir = os.path.join(
        current_app.config["UPLOAD_FOLDER"], str(current_user.org_id)
    )
    os.makedirs(org_dir, exist_ok=True)

    unique_name = f"{uuid.uuid4().hex}_{file.filename}"
    stored_path = os.path.join(org_dir, unique_name)
    file.save(stored_path)

    size_bytes = os.path.getsize(stored_path)

    uploaded_file = UploadedFile(
        filename=file.filename,
        stored_path=stored_path,
        size_bytes=size_bytes,
        content_type=file.content_type or "application/octet-stream",
        org_id=current_user.org_id,
        uploaded_by=current_user.id,
    )
    db.session.add(uploaded_file)
    db.session.commit()

    # Capture response data BEFORE dispatching the Celery task.
    # In eager mode (tests), process_file.delay() runs synchronously
    # and would change status from "pending" to "completed" before we
    # return. By capturing now, we return the state at upload time.
    response_data = {
        "id": uploaded_file.id,
        "filename": uploaded_file.filename,
        "size_bytes": uploaded_file.size_bytes,
        "status": uploaded_file.status,
    }

    from app.tasks import process_file

    process_file.delay(uploaded_file.id)

    return jsonify(response_data), 201


@files_bp.route("/", methods=["GET"])
@login_required
def list_files():
    files = UploadedFile.query.filter_by(org_id=current_user.org_id).all()
    return jsonify(
        {
            "files": [
                {
                    "id": f.id,
                    "filename": f.filename,
                    "size_bytes": f.size_bytes,
                    "content_type": f.content_type,
                    "status": f.status,
                    "created_at": f.created_at.isoformat(),
                    "processed_at": f.processed_at.isoformat()
                    if f.processed_at
                    else None,
                }
                for f in files
            ]
        }
    ), 200


@files_bp.route("/<int:file_id>", methods=["GET"])
@login_required
def get_file(file_id):
    uploaded_file = UploadedFile.query.filter_by(
        id=file_id, org_id=current_user.org_id
    ).first()
    if not uploaded_file:
        return jsonify({"error": "File not found"}), 404

    return jsonify(
        {
            "id": uploaded_file.id,
            "filename": uploaded_file.filename,
            "size_bytes": uploaded_file.size_bytes,
            "content_type": uploaded_file.content_type,
            "status": uploaded_file.status,
            "uploaded_by": uploaded_file.uploaded_by,
            "created_at": uploaded_file.created_at.isoformat(),
            "processed_at": uploaded_file.processed_at.isoformat()
            if uploaded_file.processed_at
            else None,
        }
    ), 200
