"""Authentication blueprint package."""
