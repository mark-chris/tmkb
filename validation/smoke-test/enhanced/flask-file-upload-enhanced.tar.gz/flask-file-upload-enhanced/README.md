# flask-file-upload-enhanced

A multi-tenant Flask file-upload service with asynchronous (Celery) file
processing. Users belong to organizations (tenants); files are owned by an
organization and attributed to the uploading user.

## Architecture

```
app/
  __init__.py        app factory: extensions, blueprints, error handlers, CLI
  extensions.py      db (SQLAlchemy), login_manager (Flask-Login)
  celery_app.py      Celery <-> Flask app-context integration
  tasks.py           process_file background job (re-validates auth context)
  models/
    base.py          TenantScopedMixin, SoftDeleteMixin, TimestampMixin
    organization.py  Organization (tenant)
    user.py          User (Flask-Login), belongs to one organization
    file.py          File (org-owned + user-attributed, soft-deletable)
  auth/routes.py     /auth: register, login, logout, me, users (admin)
  files/routes.py    /files: upload, list, view, download, delete
config.py            configuration (env-overridable)
run.py               dev web server entrypoint
celery_worker.py     Celery worker entrypoint
```

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Redis is the Celery broker/backend (e.g. `docker run -p 6379:6379 redis`)

export FLASK_APP=run.py
export SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
flask init-db          # create tables
```

Run the web server and a worker in two terminals:

```bash
flask run                                              # http://127.0.0.1:5000
celery -A celery_worker.celery_app worker --loglevel=info
```

## API

| Method | Path                    | Auth        | Purpose                              |
|--------|-------------------------|-------------|--------------------------------------|
| POST   | `/auth/register`        | none        | Create an org + its first admin user |
| POST   | `/auth/login`           | none        | Log in (session cookie)              |
| POST   | `/auth/logout`          | session     | Log out                              |
| GET    | `/auth/me`              | session     | Current user                         |
| POST   | `/auth/users`           | admin       | Add a user to the caller's org       |
| POST   | `/files`                | session     | Upload a file (queues processing)    |
| GET    | `/files`                | session     | List the org's files                 |
| GET    | `/files/<id>`           | session     | View one file's metadata             |
| GET    | `/files/<id>/download`  | session     | Download file bytes (when completed) |
| DELETE | `/files/<id>`           | session     | Soft-delete a file                   |

### Example session

```bash
# Register (cookies stored in cookies.txt)
curl -sc cookies.txt -X POST localhost:5000/auth/register \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@acme.test","password":"hunter2!pw","organization_name":"Acme"}'

# Upload (multipart). Returns 202 with status "pending".
curl -sb cookies.txt -X POST localhost:5000/files -F 'file=@./report.pdf'

# The worker computes size/checksum/content-type and flips status to "completed".
curl -sb cookies.txt localhost:5000/files
curl -sb cookies.txt localhost:5000/files/1
```

## Security model (sourced from TMKB)

Authorization is treated as a **boundary** problem: re-validate whenever
context crosses a boundary (endpoint → job, tenant → tenant).

- **Tenant isolation (TMKB-AUTHZ-004).** `TenantScopedMixin.tenant_query()` /
  `get_for_tenant()` inject the `organization_id` filter automatically. Routes
  never call `File.query.get()`, so a query can't silently omit the tenant
  filter and leak across tenants.
- **IDOR (TMKB-AUTHZ-007).** Get-by-id filters by id **and** org in one query
  and returns **404** (not 403) when there's no match, so ids in other tenants
  are indistinguishable from non-existent ones.
- **Background-job auth loss (TMKB-AUTHZ-001).** `process_file` receives
  `user_id` and `organization_id` and re-checks tenant match, user existence,
  user-still-in-org, and not-deleted before doing any work. A worker has an app
  context but no `current_user`, so it cannot rely on request-time auth.
- **Soft-delete resurrection (TMKB-AUTHZ-003).** Deletion is an authorization
  state: reads exclude soft-deleted rows, and a SQLAlchemy `before_update`
  guard refuses to mutate an already-deleted record (defense in depth).
- **Ownership confusion (TMKB-AUTHZ-005).** Org membership/role
  (`User.role`, `organization_id`), org-ownership (`File.organization_id`), and
  user-attribution (`File.uploaded_by_id`) are modeled distinctly.
- **Mass assignment (TMKB-AUTHZ-006).** `POST /auth/users` forces
  `organization_id` to the admin's own org and whitelists `role`; protected
  fields are never read from the request body.
- **Upload safety.** `secure_filename` + a server-generated per-org storage
  path prevent path traversal and cross-tenant filename collisions;
  `ALLOWED_EXTENSIONS` and `MAX_CONTENT_LENGTH` bound input.

## Production notes

- Swap `flask init-db` for real migrations (Flask-Migrate/Alembic).
- For defense-in-depth beyond application-level filtering, consider PostgreSQL
  Row-Level Security keyed on the tenant id (TMKB MIT-AUTHZ-004b).
- Put object storage (e.g. S3) behind the file model instead of local disk;
  serve downloads via short-lived signed URLs.
- Add antivirus / content-type verification in `process_file`.
