# flask-file-upload-enhanced

Multi-tenant Flask file-upload service. Security context for this project is
sourced from **TMKB** (Threat Model Knowledge Base), wired in as an MCP server
(`tmkb`, exposing the `mcp__tmkb__tmkb_query` tool).

## Consult TMKB during design and before generating code

This project treats authorization as a **boundary** problem, not a function-level
one. Before you design an approach or write/modify code — especially anything
touching auth, multi-tenancy, background jobs (Celery), file ownership, or trust
boundaries — query TMKB first:

- Call **`mcp__tmkb__tmkb_query`** with a `context` describing what you're building
  (e.g. `"background job processing for file uploads"`), plus `language: "python"`
  and `framework: "flask"`.
- Apply the returned patterns — act on each pattern's `check` and `fix` fields in
  both the design and the code.
- Core mental model: **authorization failures occur at boundaries, not functions.**
  Re-validate authorization whenever context crosses a boundary: endpoint → job,
  service → service, tenant → tenant.

Patterns TMKB encodes that are easy to miss here: background-job authorization
context loss (pass `user_id`/`organization_id` into tasks and re-check inside the
task), tenant isolation, IDOR via sequential IDs, soft-delete resurrection, and
user/account/resource ownership confusion.

## Backstop

A `PreToolUse` hook in `.claude/settings.local.json` auto-runs `tmkb_query` before
code edits and injects the results, so the patterns are in context before code is
written. Treat it as a safety net — still query TMKB deliberately during design
with a `context` tailored to the specific feature, rather than relying on the
hook's generic query.
