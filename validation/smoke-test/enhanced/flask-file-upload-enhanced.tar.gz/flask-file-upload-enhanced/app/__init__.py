import os

from flask import Flask, jsonify

from app.celery_app import celery_init_app
from app.extensions import db, login_manager


def create_app(config_class="config.Config"):
    app = Flask(__name__)
    app.config.from_object(config_class)

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)

    # Register models with SQLAlchemy metadata.
    from app import models  # noqa: F401

    # This is a JSON API: respond 401 instead of redirecting to a login page.
    @login_manager.unauthorized_handler
    def _unauthorized():
        return jsonify({"error": "authentication required"}), 401

    from app.auth.routes import bp as auth_bp
    from app.files.routes import bp as files_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(files_bp)

    _register_error_handlers(app)
    _register_cli(app)

    celery_init_app(app)

    @app.get("/health")
    def health():
        return jsonify({"status": "ok"})

    return app


def _register_error_handlers(app):
    @app.errorhandler(400)
    def _bad_request(e):
        return jsonify({"error": "bad request"}), 400

    @app.errorhandler(403)
    def _forbidden(e):
        return jsonify({"error": "forbidden"}), 403

    @app.errorhandler(404)
    def _not_found(e):
        return jsonify({"error": "not found"}), 404

    @app.errorhandler(413)
    def _too_large(e):
        return jsonify({"error": "file too large"}), 413

    @app.errorhandler(PermissionError)
    def _permission_error(e):
        # Raised by the soft-delete immutability guard (TMKB-AUTHZ-003).
        return jsonify({"error": "operation not permitted on a deleted resource"}), 409

    @app.errorhandler(500)
    def _server_error(e):
        return jsonify({"error": "internal server error"}), 500


def _register_cli(app):
    @app.cli.command("init-db")
    def init_db():
        """Create all database tables."""
        db.create_all()
        print("Database initialized.")
