import os
import uuid

from flask import Blueprint, abort, current_app, jsonify, request, send_file
from flask_login import current_user, login_required
from werkzeug.utils import secure_filename

from app.extensions import db
from app.models import File
from app.tasks import process_file

bp = Blueprint("files", __name__, url_prefix="/files")


def _allowed(filename):
    if "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in current_app.config["ALLOWED_EXTENSIONS"]


@bp.post("")
@login_required
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "missing 'file' part in multipart form"}), 400
    upload = request.files["file"]
    if not upload.filename:
        return jsonify({"error": "no file selected"}), 400
    if not _allowed(upload.filename):
        return jsonify({"error": "file type not allowed"}), 400

    original = secure_filename(upload.filename)

    # Store under a per-org directory using an unguessable generated name. The
    # stored path is server-derived, so a crafted filename can't traverse out of
    # the tenant's folder, and stored names can't collide or be enumerated.
    org_dir = os.path.join(
        current_app.config["UPLOAD_FOLDER"], str(current_user.organization_id)
    )
    os.makedirs(org_dir, exist_ok=True)
    stored_path = os.path.join(org_dir, f"{uuid.uuid4().hex}_{original}")
    upload.save(stored_path)

    record = File(
        organization_id=current_user.organization_id,
        uploaded_by_id=current_user.id,
        original_filename=original,
        stored_path=stored_path,
        content_type=upload.mimetype or None,
        status="pending",
    )
    db.session.add(record)
    db.session.commit()

    # Hand the job its own authorization context (TMKB-AUTHZ-001).
    task = process_file.delay(
        file_id=record.id,
        user_id=current_user.id,
        organization_id=current_user.organization_id,
    )
    record.task_id = task.id
    db.session.commit()

    return jsonify({"file": record.to_dict(), "task_id": task.id}), 202


@bp.get("")
@login_required
def list_files():
    # tenant_query() is auto-scoped to the org and excludes soft-deleted rows.
    files = File.tenant_query().order_by(File.created_at.desc()).all()
    return jsonify({"files": [f.to_dict() for f in files]})


@bp.get("/<int:file_id>")
@login_required
def get_file(file_id):
    record = File.get_for_tenant(file_id)
    if record is None:
        # 404, not 403: never reveal that an id exists in another tenant
        # (TMKB-AUTHZ-007).
        abort(404)
    return jsonify({"file": record.to_dict()})


@bp.get("/<int:file_id>/download")
@login_required
def download_file(file_id):
    record = File.get_for_tenant(file_id)
    if record is None:
        abort(404)
    if record.status != "completed":
        return jsonify({"error": f"file not ready (status={record.status})"}), 409
    return send_file(
        record.stored_path,
        as_attachment=True,
        download_name=record.original_filename,
    )


@bp.delete("/<int:file_id>")
@login_required
def delete_file(file_id):
    record = File.get_for_tenant(file_id)
    if record is None:
        abort(404)
    record.soft_delete(current_user.id)
    db.session.commit()
    return jsonify({"message": "file deleted", "file_id": file_id})
