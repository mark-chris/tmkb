import re

from flask import Blueprint, jsonify, request
from flask_login import current_user, login_required, login_user, logout_user

from app.extensions import db
from app.models import Organization, User

bp = Blueprint("auth", __name__, url_prefix="/auth")

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
MIN_PASSWORD_LEN = 8


def _error(message, status=400):
    return jsonify({"error": message}), status


@bp.post("/register")
def register():
    """Create a new organization and its first (admin) user."""
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    org_name = (data.get("organization_name") or "").strip()

    if not EMAIL_RE.match(email):
        return _error("a valid email is required")
    if len(password) < MIN_PASSWORD_LEN:
        return _error(f"password must be at least {MIN_PASSWORD_LEN} characters")
    if not org_name:
        return _error("organization_name is required")

    if User.query.filter_by(email=email).first():
        return _error("email already registered", 409)
    if Organization.query.filter_by(name=org_name).first():
        return _error("organization name already taken", 409)

    org = Organization(name=org_name)
    db.session.add(org)
    db.session.flush()  # assign org.id before creating the user

    user = User(email=email, organization_id=org.id, role="admin")
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

    login_user(user)
    return jsonify({"user": user.to_dict(), "organization": org.to_dict()}), 201


@bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    user = User.query.filter_by(email=email).first()
    # Identical response whether or not the email exists (no user enumeration).
    if user is None or not user.check_password(password):
        return _error("invalid credentials", 401)

    login_user(user)
    return jsonify({"user": user.to_dict()})


@bp.post("/logout")
@login_required
def logout():
    logout_user()
    return jsonify({"message": "logged out"})


@bp.get("/me")
@login_required
def me():
    return jsonify({"user": current_user.to_dict()})


@bp.post("/users")
@login_required
def create_user():
    """Admin-only: add a user to the caller's own organization.

    TMKB-AUTHZ-006 (mass assignment): organization_id is forced to the admin's
    own org and is never read from the request body, so an admin can't create
    users in another tenant. role is whitelisted to known values.
    """
    if not current_user.is_admin:
        return _error("admin role required", 403)

    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    role = data.get("role", "member")

    if not EMAIL_RE.match(email):
        return _error("a valid email is required")
    if len(password) < MIN_PASSWORD_LEN:
        return _error(f"password must be at least {MIN_PASSWORD_LEN} characters")
    if role not in {"member", "admin"}:
        return _error("role must be 'member' or 'admin'")
    if User.query.filter_by(email=email).first():
        return _error("email already registered", 409)

    user = User(
        email=email,
        role=role,
        organization_id=current_user.organization_id,  # forced — never client-supplied
    )
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    return jsonify({"user": user.to_dict()}), 201
