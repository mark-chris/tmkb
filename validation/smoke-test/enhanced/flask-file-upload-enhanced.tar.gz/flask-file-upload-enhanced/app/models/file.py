from app.extensions import db
from app.models.base import SoftDeleteMixin, TenantScopedMixin, TimestampMixin


class File(db.Model, TenantScopedMixin, SoftDeleteMixin, TimestampMixin):
    __tablename__ = "files"

    id = db.Column(db.Integer, primary_key=True)

    # organization_id (org-owns-resource) comes from TenantScopedMixin.
    # uploaded_by_id captures user-owns-resource separately (TMKB-AUTHZ-005).
    uploaded_by_id = db.Column(
        db.Integer, db.ForeignKey("users.id"), nullable=False, index=True
    )

    original_filename = db.Column(db.String(512), nullable=False)
    stored_path = db.Column(db.String(1024), nullable=False)
    content_type = db.Column(db.String(255), nullable=True)
    size_bytes = db.Column(db.BigInteger, nullable=True)
    checksum_sha256 = db.Column(db.String(64), nullable=True)

    # pending -> processing -> completed | failed
    status = db.Column(db.String(32), nullable=False, default="pending", index=True)
    processing_error = db.Column(db.Text, nullable=True)
    task_id = db.Column(db.String(64), nullable=True)

    uploaded_by = db.relationship("User", foreign_keys=[uploaded_by_id])

    def to_dict(self):
        return {
            "id": self.id,
            "original_filename": self.original_filename,
            "content_type": self.content_type,
            "size_bytes": self.size_bytes,
            "checksum_sha256": self.checksum_sha256,
            "status": self.status,
            "processing_error": self.processing_error,
            "organization_id": self.organization_id,
            "uploaded_by_id": self.uploaded_by_id,
            "task_id": self.task_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
