from app.extensions import db
from app.models.base import TimestampMixin


class Organization(db.Model, TimestampMixin):
    """A tenant. All tenant-scoped resources hang off this."""

    __tablename__ = "organizations"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False, unique=True)

    users = db.relationship("User", back_populates="organization", lazy="dynamic")

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
