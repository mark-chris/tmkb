"""Reusable model mixins that centralize the authorization boundaries.

The core mental model (per TMKB): authorization failures happen at
*boundaries*, not functions. These mixins make the tenant boundary and the
deletion boundary structural, so individual endpoints can't accidentally skip
them.
"""
from datetime import datetime, timezone

from flask import has_request_context
from flask_login import current_user
from sqlalchemy import event

from app.extensions import db


def utcnow():
    return datetime.now(timezone.utc)


class TimestampMixin:
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=utcnow, onupdate=utcnow, nullable=False)


class SoftDeleteMixin:
    """Soft delete with immutability enforcement.

    TMKB-AUTHZ-003: deletion state is an *authorization* concern, not just a
    read filter. A deleted record must not be modifiable or resurrectable
    regardless of ownership.
    """

    deleted_at = db.Column(db.DateTime, nullable=True, index=True)
    deleted_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

    @property
    def is_deleted(self):
        return self.deleted_at is not None

    def soft_delete(self, user_id):
        if self.is_deleted:
            raise ValueError("record is already deleted")
        self.deleted_at = utcnow()
        self.deleted_by = user_id


@event.listens_for(SoftDeleteMixin, "before_update", propagate=True)
def _block_updates_to_deleted(mapper, connection, target):
    """Defense in depth (MIT-AUTHZ-003b): refuse to flush changes to a record
    that was already soft-deleted. Setting ``deleted_at`` for the first time
    (the soft_delete itself) is allowed; mutating an already-deleted row is not.
    """
    history = db.inspect(target).attrs.deleted_at.history
    if not history.has_changes() and target.deleted_at is not None:
        raise PermissionError(
            f"cannot modify soft-deleted {target.__class__.__name__} id={target.id}"
        )


class TenantScopedMixin:
    """Automatic tenant scoping for org-owned resources.

    TMKB-AUTHZ-004: a single query that forgets the tenant filter leaks every
    tenant's data. Routes must use ``tenant_query()`` / ``get_for_tenant()``
    instead of ``Model.query.get()`` so the org filter (and soft-delete filter)
    can never be forgotten.
    """

    organization_id = db.Column(
        db.Integer, db.ForeignKey("organizations.id"), nullable=False, index=True
    )

    @classmethod
    def tenant_query(cls):
        """A query pre-filtered to the current request's tenant.

        Raises in a non-request context (e.g. a Celery worker) on purpose:
        background jobs have no ``current_user`` and must pass an explicit
        tenant id to ``get_for_tenant`` (TMKB-AUTHZ-001).
        """
        if not has_request_context():
            raise RuntimeError(
                f"cannot query {cls.__name__} outside a request context; "
                "pass an explicit tenant_id (e.g. in a background job)"
            )
        if not current_user or not current_user.is_authenticated:
            raise RuntimeError(
                f"cannot query {cls.__name__} without an authenticated user"
            )

        query = cls.query.filter_by(organization_id=current_user.organization_id)
        if hasattr(cls, "deleted_at"):
            query = query.filter(cls.deleted_at.is_(None))
        return query

    @classmethod
    def get_for_tenant(cls, id, tenant_id=None):
        """Fetch one row by id, scoped to a tenant and excluding soft-deleted.

        Returns ``None`` (not a 404 abort) so it is safe to call from both
        request handlers and background jobs. Pass ``tenant_id`` explicitly
        when there is no request context.
        """
        if tenant_id is None:
            query = cls.tenant_query()
        else:
            query = cls.query.filter_by(organization_id=tenant_id)
            if hasattr(cls, "deleted_at"):
                query = query.filter(cls.deleted_at.is_(None))
        return query.filter_by(id=id).first()
