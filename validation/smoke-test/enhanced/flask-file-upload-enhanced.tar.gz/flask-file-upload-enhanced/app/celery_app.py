"""Celery integration with the Flask application factory.

Every task runs inside a pushed Flask app context, so ``db`` and config are
available — but note that an app context is *not* a request context: there is
no ``current_user`` in a worker. Tasks must therefore carry their own
authorization context (TMKB-AUTHZ-001).
"""
from celery import Celery, Task


def celery_init_app(app):
    class FlaskTask(Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)

    celery_app = Celery(app.name, task_cls=FlaskTask)
    celery_app.config_from_object(app.config["CELERY"])
    celery_app.set_default()
    app.extensions["celery"] = celery_app
    return celery_app
