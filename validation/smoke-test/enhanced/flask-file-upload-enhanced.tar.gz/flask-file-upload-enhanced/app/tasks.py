"""Background processing for uploaded files.

TMKB-AUTHZ-001: a background job runs without the original request's
authorization context. The endpoint that enqueues the job passes ``user_id``
and ``organization_id`` explicitly, and the job re-validates all of it before
touching the resource — never trusting ``file_id`` alone.
"""
import hashlib
import logging
import mimetypes

from celery import shared_task

from app.extensions import db
from app.models import File, User

logger = logging.getLogger(__name__)

_CHUNK = 1024 * 1024


class AuthorizationError(Exception):
    """Raised when a job's re-validation of its auth context fails."""


@shared_task(bind=True, max_retries=3, default_retry_delay=10)
def process_file(self, file_id, user_id, organization_id):
    # Load with an explicit tenant filter — NOT File.query.get() (TMKB-AUTHZ-004).
    file_record = File.query.filter_by(
        id=file_id, organization_id=organization_id
    ).first()
    if file_record is None:
        logger.warning(
            "process_file: file %s not found for org %s", file_id, organization_id
        )
        return {"status": "error", "message": "file not found"}

    # Re-validate the rest of the context (TMKB-AUTHZ-001).
    # 1) tenant match — defense in depth even after the filtered load above.
    if file_record.organization_id != organization_id:
        raise AuthorizationError("tenant mismatch in background job")
    # 2) requesting user still exists and still belongs to that org.
    user = db.session.get(User, user_id)
    if user is None:
        raise AuthorizationError("requesting user no longer exists")
    if user.organization_id != organization_id:
        raise AuthorizationError("requesting user no longer in organization")
    # 3) file not soft-deleted between enqueue and execution (TMKB-AUTHZ-003).
    if file_record.is_deleted:
        logger.warning("process_file: refusing to process deleted file %s", file_id)
        return {"status": "error", "message": "file has been deleted"}

    file_record.status = "processing"
    file_record.processing_error = None
    db.session.commit()

    try:
        sha256 = hashlib.sha256()
        size = 0
        with open(file_record.stored_path, "rb") as fh:
            for chunk in iter(lambda: fh.read(_CHUNK), b""):
                sha256.update(chunk)
                size += len(chunk)

        file_record.checksum_sha256 = sha256.hexdigest()
        file_record.size_bytes = size
        if not file_record.content_type:
            guessed, _ = mimetypes.guess_type(file_record.original_filename)
            file_record.content_type = guessed
        file_record.status = "completed"
        db.session.commit()
        return {
            "status": "success",
            "file_id": file_id,
            "checksum_sha256": file_record.checksum_sha256,
            "size_bytes": size,
        }
    except Exception as exc:  # noqa: BLE001 - record failure, then retry
        logger.exception("process_file failed for file %s", file_id)
        file_record.status = "failed"
        file_record.processing_error = str(exc)
        db.session.commit()
        raise self.retry(exc=exc)
